package com.example.InternationalizationDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternationalizationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
