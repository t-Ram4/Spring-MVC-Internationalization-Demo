package com.example.InternationalizationDemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ViewController {
   @RequestMapping("locale")
   public String locale() {
	   
	   System.out.println("inside viewController");
      return "locale";
   }
}